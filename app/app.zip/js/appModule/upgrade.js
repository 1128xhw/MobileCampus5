/**
 * Created by xuhw on 2017/3/5.
 */
function getNewest(){
    MSEOP.Upgrade.checkVersion('mseop');
}
